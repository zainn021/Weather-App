document.getElementById('search-button').addEventListener('click', function() {
    searchWeather();
});

document.getElementById('search-bar').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        searchWeather();
    }
});

function searchWeather() {
    const city = document.getElementById('search-bar').value;
    const apiKey = 'd02aced5bd4acd580d3a079e93684154';
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                displayWeather(data);
            } else {
                alert('City not found. Please enter a valid city.');
            }
        })
        .catch(error => console.log('Error:', error));
}


function displayWeather(data) {
    const weatherContainer = document.createElement('div');
    weatherContainer.classList.add('weather-container');

    const cityName = document.createElement('h2');
    cityName.textContent = data.name;
    weatherContainer.appendChild(cityName);

    const temperature = document.createElement('p');
    temperature.textContent = `Temperature: ${data.main.temp} °C`;
    weatherContainer.appendChild(temperature);

    const description = document.createElement('p');
    description.textContent = `Weather: ${data.weather[0].description}`;
    weatherContainer.appendChild(description);

    const weatherImage = document.createElement('img');

    switch (data.weather[0].main) {
        case 'Clear':
            weatherImage.src = 'images/clear.png';
            backgroundImage = 'url(images/cls.png)';
            break;
        case 'Clouds':
            weatherImage.src = 'images/cloudy.png';
            backgroundImage = 'url(images/cloudysky.png)';
            break;
        case 'Rain':
            weatherImage.src = 'images/rain.png';
            backgroundImage = 'url(images/rainysky.png)';
            break;
        case 'Snow':
            weatherImage.src = 'images/snow.png';
            backgroundImage = 'url(images/snowy.png)';
            break;
        case 'Thunderstorm':
            weatherImage.src = 'images/tstorm.png';
            backgroundImage = 'url(images/thunderstormy.png)';
            break;
        case 'Drizzle':
            weatherImage.src = 'images/windy.png';
            backgroundImage = 'url(images/drizzley.png)';
            break;
        case 'Mist':
            weatherImage.src = 'images/pcloud.png';
            backgroundImage = 'url(images/misty.jpeg)';
            break;
        case 'Fog':
            weatherImage.src = 'images/fog.png';
            backgroundImage = 'url(images/foggy.jpeg)';
            break;
        case'Sunny':
            weatherImage.src='images/sunny1.png';
            backgroundImage = 'url(images/sunnny.jpeg)';
            break;
        case 'Haze':
            weatherImage.src='images/humid.png';
            backgroundImage = 'url(images/hazey.png)';  
            break; 
        default:
            weatherImage.src = 'images/default.png';
            break;
    }

    weatherContainer.appendChild(weatherImage);

    // Clear previous results
    const weatherOutput = document.getElementById('weather-output');
    weatherOutput.innerHTML = ''; // Clear previous weather data

    weatherOutput.appendChild(weatherContainer);
    document.body.style.backgroundImage = backgroundImage;
}
// Initially set the default background image
document.body.style.backgroundImage = 'url(images/thunderstormy.png)';
